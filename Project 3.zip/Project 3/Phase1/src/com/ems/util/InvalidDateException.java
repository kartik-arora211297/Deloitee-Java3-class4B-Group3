package com.ems.util;

public class InvalidDateException extends Exception{

	public InvalidDateException() {
		
	}
	public InvalidDateException(String message) {
		super(message);
	}
}
