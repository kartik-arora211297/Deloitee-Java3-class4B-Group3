package com.ems.util;

public class InvalidLengthException extends Exception{
	
public InvalidLengthException() {
		
	}
	public InvalidLengthException(String message) {
		super(message);
	}
}
